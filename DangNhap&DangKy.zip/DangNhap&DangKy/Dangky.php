<?php
session_start();

// 1. Kết nối CSDL
$conn = mysqli_connect("localhost", "root", "", "cuahangtienloi");
if (!$conn) {
    die("Kết nối CSDL thất bại: " . mysqli_connect_error());
}

// 2. Xử lý khi người dùng nhấn nút "Đăng ký"
if (isset($_POST['btn-register'])) {
    $fullname = $_POST['fullname'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    // 3. Kiểm tra mật khẩu nhập lại có khớp không
    if ($password !== $confirm_password) {
        echo "<script>alert('Mật khẩu nhập lại không khớp!'); window.history.back();</script>";
    } else {
        // 4. Kiểm tra xem tên đăng nhập (SĐT/Email) đã tồn tại trong bảng `nguoidung` chưa
        $check_sql = "SELECT * FROM nguoidung WHERE username = '$username'";
        $check_result = mysqli_query($conn, $check_sql);

        if (mysqli_num_rows($check_result) > 0) {
            echo "<script>alert('Tài khoản này đã tồn tại! Vui lòng chọn tên đăng nhập khác.'); window.history.back();</script>";
        } else {
            // 5. Nếu chưa tồn tại -> Thêm người dùng mới vào CSDL với vai_tro = 0 (Khách hàng)
            // LƯU Ý: Chắc chắn bảng nguoidung của bạn đã có cột fullname và vai_tro
            $insert_sql = "INSERT INTO nguoidung (fullname, username, password, vai_tro) 
VALUES ('$fullname', '$username', '$password', 2)";
            
            if (mysqli_query($conn, $insert_sql)) {
                echo "<script>
                    alert('Đăng ký tài khoản thành công! Mời bạn đăng nhập.');
                    window.location.href = 'Dangnhap.php';
                </script>";
            } else {
                echo "<script>alert('Đã xảy ra lỗi: " . mysqli_error($conn) . "');</script>";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Đăng ký | Cửa hàng tiện lợi</title>
    <link rel="stylesheet" href="Dangky.css"> <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>

<div class="register-wrapper">
    <div class="register-card">

        <div class="register-left">
            <img src="images/logo.png" class="logo" alt="logo">

            <h2><i class="fa-solid fa-cart-shopping"></i> ĐĂNG KÝ</h2>
            <p class="sub">Tạo tài khoản để mua sắm dễ dàng</p>

            <form action="Dangky.php" method="POST">
                <div class="input-box">
                    <i class="fa-regular fa-user"></i>
                    <input type="text" name="fullname" placeholder="Họ và tên" required>
                </div>

                <div class="input-box">
                    <i class="fa-solid fa-phone"></i>
                    <input type="text" name="username" placeholder="Số điện thoại hoặc email" required>
                </div>

                <div class="input-box">
                    <i class="fa-solid fa-lock"></i>
                    <input type="password" name="password" placeholder="Mật khẩu" required>
                </div>

                <div class="input-box">
                    <i class="fa-solid fa-lock"></i>
                    <input type="password" name="confirm_password" placeholder="Nhập lại mật khẩu" required>
                </div>

                <button type="submit" name="btn-register" class="btn-register">Đăng ký</button>
            </form>

            <button class="btn-facebook">
                <i class="fa-brands fa-facebook-f"></i>
                Đăng ký bằng Facebook
            </button>

            <p class="register">
                Đã có tài khoản?
                <a href="Dangnhap.php">Đăng nhập ngay</a>
            </p>
        </div>

        <div class="register-right">
            <img src="images/shipper.png" alt="Shipper">
        </div>

    </div>
</div>

</body>
</html>