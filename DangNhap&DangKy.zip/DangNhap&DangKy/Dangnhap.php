<?php
session_start();

// 1. Kết nối CSDL
$conn = mysqli_connect("localhost", "root", "", "cuahangtienloi");
if (!$conn) {
    die("Kết nối CSDL thất bại: " . mysqli_connect_error());
}
if (isset($_POST['btn-login'])) {
    $u = $_POST['username'];
    $p = $_POST['password'];

    $sql = "SELECT * FROM nguoidung WHERE username = '$u' AND password = '$p'";
    $result = mysqli_query($conn, $sql);

    if (!$result) {
        die("Lỗi SQL: " . mysqli_error($conn));
    }

    if (mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);

        // Lưu session
        $_SESSION['username'] = $row['username'];
        $_SESSION['vai_tro'] = $row['vai_tro'];

        // PHÂN QUYỀN
        if ($row['vai_tro'] == 1) {
            header("Location: ../Quanly/Quanly.php");
        } else if ($row['vai_tro'] == 2) {
            header("Location: ../Danhmucsanpham/Sanpham.php");
        }

        exit();

    } else {
        echo "<script>alert('Sai tài khoản hoặc mật khẩu!'); window.history.back();</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Đăng nhập | Cửa hàng tiện lợi</title>
    <link rel="stylesheet" href="Dangnhap.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>

<div class="login-wrapper">
    <div class="login-card">

        <div class="login-left">
            <img src="images/logo.png" class="logo" alt="logo">
            
            <form action="Dangnhap.php" method="POST">
                <h2><i class="fa-solid fa-cart-shopping"></i> ĐĂNG NHẬP</h2>
                <p class="sub">Đăng nhập để tiếp tục mua sắm</p>

                <div class="input-box">
                    <i class="fa-regular fa-user"></i>
                    <input type="text" name="username" placeholder="Số điện thoại hoặc email" required>
                </div>

                <div class="input-box">
                    <i class="fa-solid fa-lock"></i>
                    <input type="password" name="password" placeholder="Nhập mật khẩu" required>
                </div>

                <a href="#" class="forgot">Quên mật khẩu?</a>

                <button type="submit" name="btn-login" class="btn-login">Đăng Nhập</button>
            </form>

            <button class="btn-facebook">
                <i class="fa-brands fa-facebook-f"></i>
                Đăng nhập bằng Facebook
            </button>

            <p class="register">
                Chưa có tài khoản?
                <a href="Dangky.php">Đăng ký ngay</a>
            </p>
            
            <div class="support">
                <span><i class="fa-solid fa-headset"></i> Hỗ trợ khách hàng</span>
                <span><i class="fa-solid fa-circle-question"></i> Cần trợ giúp</span>
            </div>
        </div>

        <div class="login-right">
            <img src="images/shipper.png" alt="Shipper">
        </div>

    </div>
</div>

</body>
</html>