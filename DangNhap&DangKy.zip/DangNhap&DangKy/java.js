const form = document.querySelector("form");
form.addEventListener("submit", function(e) {
    const pass = document.querySelector('input[name="password"]').value;
    const confirm = document.querySelector('input[name="confirm_password"]').value;

    if (pass !== confirm) {
        alert("Mật khẩu không khớp!");
        e.preventDefault();
    }
});