<?php
// ================= KẾT NỐI =================
$conn = new mysqli("localhost", "root", "", "cuahangtienloi");
$conn->set_charset("utf8");

if ($conn->connect_error) {
    die("Lỗi kết nối database!");
}

// ================= KIỂM TRA ID =================
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($id <= 0) {
    die("Thiếu ID đơn hàng!");
}

// ================= LẤY THÔNG TIN ĐƠN HÀNG =================
$sql1 = "
SELECT don_hang.*, khach_hang.ten_khach_hang
FROM don_hang
JOIN khach_hang 
ON don_hang.id_khach_hang = khach_hang.id_khach_hang
WHERE don_hang.id_don_hang = $id
";

$result = $conn->query($sql1);

if (!$result || $result->num_rows == 0) {
    die("Không tìm thấy đơn hàng!");
}

$donhang = $result->fetch_assoc();


// ================= LẤY CHI TIẾT ĐƠN HÀNG =================
$sql2 = "
SELECT 
    chi_tiet_don_hang.so_luong,
    chi_tiet_don_hang.gia,
    san_pham.ten_san_pham
FROM chi_tiet_don_hang
JOIN san_pham 
ON chi_tiet_don_hang.id_san_pham = san_pham.id_san_pham
WHERE chi_tiet_don_hang.id_don_hang = $id
";

$chitiet = $conn->query($sql2);

if (!$chitiet) {
    die("Lỗi truy vấn chi tiết đơn hàng!");
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<title>Chi tiết hóa đơn</title>

<link rel="stylesheet" href="Lichsu.css">
</head>

<body>

<div class="container">

<h1>Chi tiết hóa đơn #<?= $donhang['ma_hd']; ?></h1>

<p><b>Khách hàng:</b> <?= $donhang['ten_khach_hang']; ?></p>
<p><b>Ngày:</b> <?= date("d/m/Y", strtotime($donhang['ngay'])); ?></p>
<p><b>Thanh toán:</b> <?= $donhang['thanh_toan']; ?></p>

<hr>

<h3>Danh sách sản phẩm</h3>

<table border="1" width="100%" cellpadding="10">
<tr>
    <th>Tên sản phẩm</th>
    <th>Số lượng</th>
    <th>Giá</th>
    <th>Thành tiền</th>
</tr>

<?php if ($chitiet->num_rows > 0) { ?>
    <?php while($row = $chitiet->fetch_assoc()) { ?>
        <tr>
            <td><?= $row['ten_san_pham']; ?></td>
            <td><?= $row['so_luong']; ?></td>
            <td><?= number_format($row['gia']); ?>đ</td>
            <td><?= number_format($row['so_luong'] * $row['gia']); ?>đ</td>
        </tr>
    <?php } ?>
<?php } else { ?>
    <tr>
        <td colspan="4">Chưa có sản phẩm trong đơn hàng</td>
    </tr>
<?php } ?>

</table>

<h2 style="margin-top:20px;">
Tổng tiền: <?= number_format($donhang['tong_tien']); ?>đ
</h2>

<br>

<a href="Lichsu.php">← Quay lại</a>

</div>

</body>
</html>