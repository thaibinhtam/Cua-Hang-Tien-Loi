<?php
session_start();

// 1. Xóa tất cả các biến session
$_SESSION = array();

// 2. Nếu muốn xóa sạch cả Cookie session thì thêm phần này (tùy chọn nhưng nên có)
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

// 3. Hủy bỏ phiên làm việc
session_destroy();

// 4. Chuyển hướng về trang đăng nhập
header("Location: ../DangNhap&DangKy/Dangnhap.php");

exit();
?>