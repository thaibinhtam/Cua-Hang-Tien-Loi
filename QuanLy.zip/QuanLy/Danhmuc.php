<?php
session_start();

// 1. Kiểm tra quyền truy cập (Tránh người lạ vô phá)
if (!isset($_SESSION['username']) || !isset($_SESSION['vai_tro']) || $_SESSION['vai_tro'] != 1) {
    header("Location: Dangnhap.php");
    exit();
}

error_reporting(E_ALL);
ini_set('display_errors', 1);

// 2. Kết nối CSDL
$conn = new mysqli("localhost", "root", "", "cuahangtienloi");
if ($conn->connect_error) {
    die("Kết nối thất bại: " . $conn->connect_error);
}
$conn->set_charset("utf8");

// ================= THÊM =================
if(isset($_POST['them'])){
    $ten = $_POST['ten_danh_muc'];
    $mota = $_POST['mo_ta'];

    $conn->query("INSERT INTO danh_muc(ten_danh_muc, mo_ta) VALUES ('$ten','$mota')");
    header("Location: Danhmuc.php");
    exit();
}

// ================= XÓA =================
if(isset($_GET['xoa'])){
    $id = $_GET['xoa'];
    $conn->query("DELETE FROM danh_muc WHERE id_danh_muc = $id");
    header("Location: Danhmuc.php");
    exit();
}

// ================= SỬA =================
$edit = null;
if(isset($_GET['sua'])){
    $id = $_GET['sua'];
    $kq = $conn->query("SELECT * FROM danh_muc WHERE id_danh_muc = $id");
    if($kq->num_rows > 0) {
        $edit = $kq->fetch_assoc();
    }
}

// ================= CẬP NHẬT =================
if(isset($_POST['capnhat'])){
    $id = $_POST['id_danh_muc'];
    $ten = $_POST['ten_danh_muc'];
    $mota = $_POST['mo_ta'];

    $conn->query("UPDATE danh_muc SET ten_danh_muc='$ten', mo_ta='$mota' WHERE id_danh_muc=$id");
    header("Location: Danhmuc.php");
    exit();
}

// ================= TÌM KIẾM & LẤY DỮ LIỆU CHUẨN =================
$keyword = "";
if(isset($_GET['keyword'])){
    $keyword = $_GET['keyword'];
}

// Gộp chung 1 câu SQL duy nhất để vừa lấy dữ liệu, vừa tìm kiếm, vừa đếm số lượng SP
$sql_table = "SELECT danh_muc.*, COUNT(sanpham.id) as so_sp 
              FROM danh_muc 
              LEFT JOIN sanpham ON danh_muc.id_danh_muc = sanpham.danh_muc 
              WHERE danh_muc.ten_danh_muc LIKE '%$keyword%'
              GROUP BY danh_muc.id_danh_muc 
              ORDER BY danh_muc.id_danh_muc DESC";
$result_table = $conn->query($sql_table);
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Quản lý Danh mục</title>
    <link rel="stylesheet" href="Danhmuc.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>

<div class="wrapper">

    <div class="header">
        <div>
            <h1>Danh mục sản phẩm</h1>
            <p>Quản lý phân loại sản phẩm trong cửa hàng</p>
        </div>
    </div>

    <div class="container-box">

        <div class="search-box card">
            <form method="GET">
                <input type="text" name="keyword" placeholder="🔍 Nhập tên danh mục cần tìm..." value="<?= htmlspecialchars($keyword); ?>">
                <button type="submit" class="btn-search">Tìm kiếm</button>
            </form>
        </div>

        <?php if($edit){ ?>
        <div class="form-them card">
            <h3><i class="fa-solid fa-pen-to-square"></i> Cập nhật Danh mục</h3>
            <form method="POST">
                <input type="hidden" name="id_danh_muc" value="<?= $edit['id_danh_muc']; ?>">

                <div class="form-row">
                    <div class="form-group">
                        <label>Tên danh mục</label>
                        <input type="text" name="ten_danh_muc" value="<?= $edit['ten_danh_muc']; ?>" required>
                    </div>
                    <div class="form-group" style="flex: 2;">
                        <label>Mô tả ngắn</label>
                        <input type="text" name="mo_ta" value="<?= $edit['mo_ta']; ?>">
                    </div>
                </div>

                <div class="form-actions">
                    <button type="submit" name="capnhat" class="btn-save">💾 Lưu thay đổi</button>
                    <a href="Danhmuc.php" class="btn-cancel">Hủy bỏ</a>
                </div>
            </form>
        </div>

        <?php } else { ?>
        <div class="form-them card">
            <h3><i class="fa-solid fa-folder-plus"></i> Thêm Danh mục mới</h3>
            <form method="POST">
                <div class="form-row">
                    <div class="form-group">
                        <label>Tên danh mục</label>
                        <input type="text" name="ten_danh_muc" placeholder="VD: Nước giải khát..." required>
                    </div>
                    <div class="form-group" style="flex: 2;">
                        <label>Mô tả ngắn</label>
                        <input type="text" name="mo_ta" placeholder="Nhập mô tả cho danh mục này...">
                    </div>
                </div>

                <button type="submit" name="them" class="btn-save">+ Thêm danh mục</button>
            </form>
        </div>
        <?php } ?>

        <div class="card">
            <table>
                <thead>
                    <tr>
                        <th width="5%">STT</th>
                        <th width="25%">Tên danh mục</th>
                        <th width="30%">Mô tả</th>
                        <th width="15%" style="text-align: center;">Số sản phẩm</th>
                        <th width="15%">Ngày tạo</th>
                        <th width="10%" style="text-align: center;">Hành động</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    if($result_table && $result_table->num_rows > 0) { 
                        $stt = 1;
                        while($row = $result_table->fetch_assoc()) { 
                    ?>
                        <tr>
                            <td><b><?= $stt++; ?></b></td>
                            <td><span style="font-weight: 600; color: #1e3a8a;"><?= $row['ten_danh_muc']; ?></span></td>
                            <td><?= $row['mo_ta'] ? $row['mo_ta'] : '<i style="color:#94a3b8;">Không có mô tả</i>'; ?></td>
                            <td style="text-align: center;">
                                <span class="category-tag"><?= $row['so_sp']; ?> SP</span>
                            </td>
                            <td><?= date("d/m/Y", strtotime($row['ngay_tao'])); ?></td>
                            <td style="text-align: center;">
                                <a href="?sua=<?= $row['id_danh_muc']; ?>" class="action-btn edit" title="Sửa"><i class="fa-solid fa-pen"></i></a>
                                <a href="?xoa=<?= $row['id_danh_muc']; ?>" class="action-btn delete" title="Xóa" onclick="return confirm('Xác nhận xóa danh mục này?')"><i class="fa-solid fa-trash"></i></a>
                            </td>
                        </tr>
                    <?php 
                        } 
                    } else { 
                    ?>
                        <tr><td colspan="6" style="text-align: center; color: red; padding: 20px;">Không tìm thấy danh mục nào!</td></tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>

    </div>
    
    <a href="Quanly.php" class="back-btn">
        <i class="fa-solid fa-arrow-left"></i> Quay lại Tổng quan
    </a>
</div>

</body>
</html>