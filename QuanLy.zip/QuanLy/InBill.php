<?php
session_start();

// Kiểm tra quyền
if (!isset($_SESSION['username']) || !isset($_SESSION['vai_tro']) || $_SESSION['vai_tro'] != 1) {
    header("Location: Dangnhap.php");
    exit();
}

// Kiểm tra xem có truyền mã hóa đơn qua không
if (!isset($_GET['ma_hd'])) {
    die("Không tìm thấy mã hóa đơn!");
}
$ma_hd = $_GET['ma_hd'];

// Kết nối CSDL
$conn = new mysqli("localhost", "root", "", "cuahangtienloi");
$conn->set_charset("utf8");

// Lấy thông tin đơn hàng
$sql_hd = "SELECT * FROM don_hang WHERE ma_hd = '$ma_hd'";
$rs_hd = $conn->query($sql_hd);
if ($rs_hd->num_rows == 0) {
    die("Hóa đơn không tồn tại!");
}
$don_hang = $rs_hd->fetch_assoc();
$id_don_hang = $don_hang['id_don_hang'];

// Lấy chi tiết các món hàng trong đơn
$sql_ct = "SELECT ct.*, sp.ten_sp 
           FROM chi_tiet_don_hang ct 
           JOIN sanpham sp ON ct.id_san_pham = sp.id 
           WHERE ct.id_don_hang = '$id_don_hang'";
$rs_ct = $conn->query($sql_ct);
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>In Hóa Đơn - <?= $ma_hd ?></title>
    <style>
        /* CSS giả lập hóa đơn máy in nhiệt */
        body {
            background: #e2e8f0;
            font-family: 'Courier New', Courier, monospace; /* Font chữ chuẩn máy in */
            font-size: 14px;
            color: #000;
        }
        .bill-container {
            width: 320px; /* Khổ giấy 80mm */
            background: #fff;
            margin: 20px auto;
            padding: 20px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }
        .store-name {
            text-align: center;
            font-size: 20px;
            font-weight: bold;
            margin-bottom: 5px;
        }
        .store-info, .bill-info {
            text-align: center;
            margin-bottom: 15px;
            font-size: 12px;
        }
        .divider {
            border-bottom: 1px dashed #000;
            margin: 10px 0;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            text-align: left;
            padding: 5px 0;
            font-size: 13px;
        }
        .text-right {
            text-align: right;
        }
        .text-center {
            text-align: center;
        }
        .total-row {
            font-weight: bold;
            font-size: 16px;
        }
        .footer-text {
            text-align: center;
            margin-top: 15px;
            font-size: 12px;
            font-style: italic;
        }
        
        /* Các nút bấm sẽ bị ẩn đi khi máy tính in ra giấy */
        @media print {
            body { background: #fff; margin: 0; }
            .bill-container { box-shadow: none; margin: 0; padding: 0; width: 100%; }
            .no-print { display: none !important; }
        }

        .btn-group { text-align: center; margin-top: 20px; }
        .btn { padding: 10px 20px; border: none; cursor: pointer; font-weight: bold; border-radius: 5px; text-decoration: none; display: inline-block; }
        .btn-print { background: #3b82f6; color: #fff; }
        .btn-back { background: #cbd5e1; color: #0f172a; margin-left: 10px; }
    </style>
</head>
<body>

    <div class="bill-container">
        <div class="store-name">CỬA HÀNG TIỆN LỢI</div>
        <div class="store-info">
            Đ/C: Trái Đất, Hệ Mặt Trời<br>
            Hotline: 0123.456.789
        </div>

        <div class="divider"></div>

        <div class="bill-info">
            <strong>HÓA ĐƠN BÁN LẺ</strong><br>
            Số phiếu: <?= $ma_hd ?><br>
            Ngày: <?= date("d/m/Y H:i", strtotime($don_hang['ngay'])) ?><br>
            Thu ngân: Admin
        </div>

        <div class="divider"></div>

        <table>
            <thead>
                <tr>
                    <th style="width: 50%;">Tên món</th>
                    <th class="text-center" style="width: 15%;">SL</th>
                    <th class="text-right" style="width: 35%;">Thành tiền</th>
                </tr>
            </thead>
            <tbody>
                <?php while($item = $rs_ct->fetch_assoc()): ?>
                <tr>
                    <td><?= $item['ten_sp'] ?></td>
                    <td class="text-center"><?= $item['so_luong'] ?></td>
                    <td class="text-right"><?= number_format($item['gia'] * $item['so_luong']) ?>đ</td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>

        <div class="divider"></div>

        <table>
            <tr class="total-row">
                <td>TỔNG CỘNG:</td>
                <td class="text-right"><?= number_format($don_hang['tong_tien']) ?>đ</td>
            </tr>
            <tr>
                <td>Khách đưa:</td>
                <td class="text-right"><?= number_format($don_hang['tong_tien']) ?>đ</td>
            </tr>
            <tr>
                <td>Tiền thừa:</td>
                <td class="text-right">0đ</td>
            </tr>
        </table>

        <div class="divider"></div>

        <div class="footer-text">
            Cảm ơn Quý khách & Hẹn gặp lại!<br>
            (Pass Wifi: xincamon)
        </div>

        <div class="btn-group no-print">
            <button class="btn btn-print" onclick="window.print()"><i class="fa-solid fa-print"></i> In Hóa Đơn</button>
            <a href="POS.php" class="btn btn-back">Về POS</a>
        </div>
    </div>

    <script>
        window.onload = function() {
            window.print();
        };
    </script>

</body>
</html>