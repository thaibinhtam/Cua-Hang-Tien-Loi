<?php
session_start();

// 1. Kiểm tra quyền truy cập Admin
if (!isset($_SESSION['username']) || !isset($_SESSION['vai_tro']) || $_SESSION['vai_tro'] != 1) {
    header("Location: Dangnhap.php");
    exit();
}

error_reporting(E_ALL);
ini_set('display_errors', 1);

// 2. Kết nối CSDL
$conn = new mysqli("localhost", "root", "", "cuahangtienloi");
if ($conn->connect_error) {
    die("Kết nối thất bại: " . $conn->connect_error);
}
$conn->set_charset("utf8");

// ================= XÓA KHÁCH HÀNG =================
if(isset($_GET['xoa'])){
    $id = $_GET['xoa'];
    $conn->query("DELETE FROM khach_hang WHERE id_khach_hang = $id");
    header("Location: Khachhang.php");
    exit();
}

// ================= THÊM & CẬP NHẬT KHÁCH HÀNG =================
if(isset($_POST['save'])){
    $id = $_POST['id_khach_hang'];
    $ten = $_POST['ten_khach_hang'];
    $sdt = $_POST['sdt'];
    $email = $_POST['email'];
    $chitieu = $_POST['tong_chi_tieu'];

    // Tính năng xịn: Tự động set VIP nếu chi tiêu >= 5 triệu
    $trangthai = ($chitieu >= 5000000) ? 'VIP' : 'Thường';

    if($id == "") {
        // Thêm mới (Vì ID rỗng)
        $conn->query("INSERT INTO khach_hang(ten_khach_hang, sdt, email, tong_chi_tieu, trang_thai) 
                      VALUES ('$ten', '$sdt', '$email', '$chitieu', '$trangthai')");
    } else {
        // Cập nhật (Vì có ID)
        $conn->query("UPDATE khach_hang SET 
                      ten_khach_hang='$ten', sdt='$sdt', email='$email', 
                      tong_chi_tieu='$chitieu', trang_thai='$trangthai' 
                      WHERE id_khach_hang=$id");
    }
    header("Location: Khachhang.php");
    exit();
}

// ================= CHUẨN BỊ DỮ LIỆU ĐỂ SỬA =================
$edit = null;
if(isset($_GET['sua'])){
    $id = $_GET['sua'];
    $res = $conn->query("SELECT * FROM khach_hang WHERE id_khach_hang = $id");
    if($res->num_rows > 0) {
        $edit = $res->fetch_assoc();
    }
}

// ================= TÌM KIẾM & LẤY DANH SÁCH =================
$keyword = isset($_GET['keyword']) ? $_GET['keyword'] : "";
$sql = "SELECT * FROM khach_hang WHERE ten_khach_hang LIKE '%$keyword%' OR sdt LIKE '%$keyword%' ORDER BY id_khach_hang DESC";
$result = $conn->query($sql);
// BẮT LỖI SQL:
if (!$result) {
    echo "<div style='background: #fee2e2; color: #dc2626; padding: 15px; margin: 20px; text-align: center; border-radius: 8px;'>
            <b>🚨 LỖI DATABASE:</b> " . $conn->error . "
          </div>";
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Quản lý Khách hàng</title>
    <link rel="stylesheet" href="Danhmuc.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>

<div class="wrapper">
    <div class="header">
        <div>
            <h1>Quản lý Khách hàng</h1>
            <p>Theo dõi thông tin và phân loại khách hàng VIP của cửa hàng</p>
        </div>
    </div>

    <div class="container-box">
        <div class="search-box card">
            <form method="GET">
                <input type="text" name="keyword" placeholder="🔍 Nhập tên hoặc SĐT khách hàng cần tìm..." value="<?= htmlspecialchars($keyword) ?>">
                <button type="submit" class="btn-search">Tìm kiếm</button>
            </form>
        </div>

        <div class="form-them card">
            <h3><?= $edit ? '<i class="fa-solid fa-user-pen"></i> Cập nhật thông tin' : '<i class="fa-solid fa-user-plus"></i> Thêm khách hàng mới' ?></h3>
            <form method="POST">
                <input type="hidden" name="id_khach_hang" value="<?= $edit['id_khach_hang'] ?? '' ?>">

                <div class="form-row">
                    <div class="form-group">
                        <label>Họ tên khách hàng</label>
                        <input type="text" name="ten_khach_hang" value="<?= $edit['ten_khach_hang'] ?? '' ?>" required>
                    </div>
                    <div class="form-group">
                        <label>Số điện thoại</label>
                        <input type="text" name="sdt" value="<?= $edit['sdt'] ?? '' ?>" required>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label>Email liên hệ</label>
                        <input type="email" name="email" value="<?= $edit['email'] ?? '' ?>">
                    </div>
                    <div class="form-group">
                        <label>Tổng chi tiêu (VNĐ)</label>
                        <input type="number" name="tong_chi_tieu" value="<?= $edit['tong_chi_tieu'] ?? '0' ?>" required>
                    </div>
                </div>

                <div class="form-actions">
                    <button type="submit" name="save" class="btn-save">
                        <?= $edit ? '💾 Lưu thay đổi' : '+ Thêm khách hàng' ?>
                    </button>
                    <?php if($edit): ?>
                        <a href="Khachhang.php" class="btn-cancel">Hủy bỏ</a>
                    <?php endif; ?>
                </div>
            </form>
        </div>

        <div class="card">
            <table>
                <thead>
                    <tr>
                        <th>STT</th>
                        <th>Họ tên</th>
                        <th>Số điện thoại</th>
                        <th>Email</th>
                        <th>Tổng chi tiêu</th>
                        <th style="text-align: center;">Hạng</th>
                        <th style="text-align: center;">Hành động</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $stt = 1;
                    if($result && $result->num_rows > 0) {
                        while($row = $result->fetch_assoc()): 
                    ?>
                    <tr>
                        <td><b><?= $stt++ ?></b></td>
                        <td><span style="font-weight: 600; color: #1e3a8a;"><?= $row['ten_khach_hang'] ?></span></td>
                        <td><?= $row['sdt'] ?></td>
                        <td><?= $row['email'] ? $row['email'] : '<i style="color:#cbd5e1;">Không có</i>' ?></td>
                        <td><span class="price-tag"><?= number_format($row['tong_chi_tieu'], 0, ',', '.') ?>đ</span></td>
                        <td style="text-align: center;">
                            <?php if($row['trang_thai'] == 'VIP'): ?>
                                <span style="background: #fef08a; color: #b45309; padding: 5px 10px; border-radius: 20px; font-size: 12px; font-weight: bold;">
                                    <i class="fa-solid fa-crown"></i> VIP
                                </span>
                            <?php else: ?>
                                <span style="background: #f1f5f9; color: #64748b; padding: 5px 10px; border-radius: 20px; font-size: 12px; font-weight: bold;">
                                    Thường
                                </span>
                            <?php endif; ?>
                        </td>
                        <td style="text-align: center;">
                            <a href="?sua=<?= $row['id_khach_hang'] ?>" class="action-btn edit" title="Sửa"><i class="fa-solid fa-pen"></i></a>
                            <a href="?xoa=<?= $row['id_khach_hang'] ?>" class="action-btn delete" title="Xóa" onclick="return confirm('Xác nhận xóa khách hàng này?')"><i class="fa-solid fa-trash"></i></a>
                        </td>
                    </tr>
                    <?php 
                        endwhile; 
                    } else {
                        echo "<tr><td colspan='7' style='text-align:center; padding: 20px; color: red;'>Không có dữ liệu khách hàng!</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>

    </div>
    
    <a href="Quanly.php" class="back-btn">
        <i class="fa-solid fa-arrow-left"></i> Quay lại Tổng quan
    </a>
</div>

</body>
</html>