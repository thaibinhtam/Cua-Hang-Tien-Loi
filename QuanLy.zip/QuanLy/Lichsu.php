<?php
session_start();
date_default_timezone_set('Asia/Ho_Chi_Minh');

// check login
if (!isset($_SESSION['username']) || !isset($_SESSION['vai_tro']) || $_SESSION['vai_tro'] != 1) {
    header("Location: ../DangNhap&DangKy/Dangnhap.php");
    exit();
}

// kết nối
$conn = new mysqli("localhost", "root", "", "cuahangtienloi");
$conn->set_charset("utf8");

// ================= FILTER =================
$keyword = $_GET['keyword'] ?? "";
$date = $_GET['date'] ?? "";
$status = $_GET['status'] ?? "";

// ================= SQL (GỘP BẢNG don_hang VÀ donhang BẰNG UNION) =================
$sql = "
SELECT * FROM (
    -- LẤY ĐƠN TẠI QUẦY (POS)
    SELECT 
        don_hang.id_don_hang AS id,
        don_hang.ma_hd AS ma_hd,
        khach_hang.ten_khach_hang AS ten_khach_hang,
        don_hang.ngay AS ngay,
        don_hang.tong_tien AS tong_tien,
        don_hang.thanh_toan AS thanh_toan,
        don_hang.trang_thai AS trang_thai,
        'POS' AS loai_don
    FROM don_hang
    LEFT JOIN khach_hang ON don_hang.id_khach_hang = khach_hang.id_khach_hang

    UNION ALL

    -- LẤY ĐƠN ONLINE (WEB)
    SELECT 
        donhang.id AS id,
        CONCAT('WEB-', donhang.id) AS ma_hd,
        donhang.username AS ten_khach_hang,
        donhang.ngay_dat AS ngay,
        donhang.tong_tien AS tong_tien,
        'Tiền mặt (COD)' AS thanh_toan,
        donhang.trang_thai AS trang_thai, 
        'WEB' AS loai_don
    FROM donhang
) AS bang_gop
WHERE 1
";

if($keyword != ""){
    $sql .= " AND ma_hd LIKE '%$keyword%'";
}
if($date != ""){
    $sql .= " AND DATE(ngay) = '$date'";
}
if($status != "" && $status != "all"){
    $sql .= " AND trang_thai = '$status'";
}

$sql .= " ORDER BY ngay DESC";

$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<title>Lịch sử bán hàng</title>
<link rel="stylesheet" href="Lichsu.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>

<div class="container">
<div class="header">
    <h1>Lịch sử bán hàng</h1>
    <p>Quản lý giao dịch POS và Online</p>
</div>

<form method="GET" class="filter-box">
    <input type="text" name="keyword" placeholder="🔍 Tìm theo mã hóa đơn..." value="<?php echo htmlspecialchars($keyword); ?>">
    <input type="date" name="date" value="<?php echo $date; ?>">
    <select name="status">
        <option value="all">Tất cả trạng thái</option>
        <option value="Hoàn thành" <?php if($status=="Hoàn thành") echo "selected"; ?>>Hoàn thành</option>
        <option value="Đang xử lý" <?php if($status=="Đang xử lý") echo "selected"; ?>>Đang xử lý</option>
        <option value="Đã hủy" <?php if($status=="Đã hủy") echo "selected"; ?>>Đã hủy</option>
    </select>
    <button type="submit">Lọc</button>
</form>

<div class="card">
<table>
<thead>
<tr>
    <th>Mã HD</th>
    <th>Khách hàng</th>
    <th>Ngày & Giờ</th>
    <th>Tổng tiền</th>
    <th>Thanh toán</th>
    <th>Trạng thái</th>
    <th>Hành động</th>
</tr>
</thead>
<tbody>

<?php if($result && $result->num_rows > 0){ ?>
    <?php while($row = $result->fetch_assoc()) { ?>
<tr>
    <td>
        <b>#<?php echo $row['ma_hd']; ?></b><br>
        <?php if($row['loai_don'] == 'WEB'): ?>
            <span style="background: #3b82f6; color: white; padding: 3px 6px; border-radius: 4px; font-size: 10px;">🌐 Online</span>
        <?php else: ?>
            <span style="background: #8b5cf6; color: white; padding: 3px 6px; border-radius: 4px; font-size: 10px;">🏪 Tại quầy</span>
        <?php endif; ?>
    </td>

    <td>
        <?php 
        if(!empty($row['ten_khach_hang'])){
            echo '<span style="color: #1e3a8a; font-weight: bold;">' . $row['ten_khach_hang'] . '</span>';
        } else {
            echo '<span style="color: #94a3b8; font-style: italic;"><i class="fa-solid fa-person-walking"></i> Khách vãng lai</span>';
        }
        ?>
    </td>

    <td><?php echo date("d/m/Y - H:i", strtotime($row['ngay'])); ?></td>
    <td><span style="color: #ef4444; font-weight: bold;"><?php echo number_format($row['tong_tien']); ?>đ</span></td>
    <td><?php echo $row['thanh_toan']; ?></td>

    <td>
        <?php 
        if($row['trang_thai']=="Hoàn thành"){
            echo '<span class="status done" style="background: #dcfce7; color: #16a34a; padding: 5px 10px; border-radius: 20px; font-size: 12px; font-weight: bold;">Hoàn thành</span>';
        } elseif($row['trang_thai']=="Đang xử lý"){
            echo '<span class="status process" style="background: #fef08a; color: #b45309; padding: 5px 10px; border-radius: 20px; font-size: 12px; font-weight: bold;">Đang xử lý</span>';
        } else {
            echo '<span class="status cancel" style="background: #fee2e2; color: #dc2626; padding: 5px 10px; border-radius: 20px; font-size: 12px; font-weight: bold;">Đã hủy</span>';
        }
        ?>
    </td>

    <td>
        <a href="Chitietdonhang.php?id=<?= $row['id']; ?>&loai=<?= $row['loai_don']; ?>" class="view" style="color: #3b82f6; font-size: 18px;">
            <i class="fa fa-eye"></i>
        </a>
    </td>
</tr>
    <?php } ?>
<?php } else { ?>
<tr>
    <td colspan="7" style="text-align: center; padding: 20px; color: red;">Không có dữ liệu đơn hàng nào.</td>
</tr>
<?php } ?>

</tbody>
</table>
</div>

<a href="Quanly.php" class="back-btn" style="display: inline-block; margin-top: 20px; text-decoration: none; color: #475569;">
    <i class="fa-solid fa-arrow-left"></i> Quay lại Tổng quan
</a>
</div>

</body>
</html>