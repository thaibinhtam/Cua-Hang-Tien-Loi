<?php
session_start();

// 1. Kiểm tra quyền truy cập
if (!isset($_SESSION['username']) || !isset($_SESSION['vai_tro']) || $_SESSION['vai_tro'] != 1) {
    echo "<script>
            alert('⛔ Bạn không có quyền truy cập hoặc chưa đăng nhập!');
            window.location.replace('Dangnhap.php');
          </script>";
    exit();
}

// 2. Kết nối CSDL
$conn = new mysqli("localhost", "root", "", "cuahangtienloi");
if ($conn->connect_error) {
    die("Kết nối thất bại: " . $conn->connect_error);
}
$conn->set_charset("utf8");

$thongbao = ""; // Biến lưu tin nhắn thông báo

// 3. Xử lý khi người dùng nhấn nút Cập nhật
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['btn_update'])) {
    $username = $_SESSION['username'];
    $old_pass = $_POST['old_pass'];
    $new_pass = $_POST['new_pass'];
    $confirm_pass = $_POST['confirm_pass'];

    // Lấy mật khẩu hiện tại từ DB (Giả sử bảng tên là tai_khoan)
    $stmt = $conn->prepare("SELECT password FROM tai_khoan WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    if (!$user) {
        $thongbao = "<div class='alert error'>Lỗi: Không tìm thấy tài khoản!</div>";
    } elseif ($old_pass !== $user['password']) {
        // Lưu ý: Nếu bạn dùng password_hash() khi đăng ký thì dùng password_verify() ở đây
        $thongbao = "<div class='alert error'>❌ Mật khẩu hiện tại không đúng!</div>";
    } elseif ($new_pass !== $confirm_pass) {
        $thongbao = "<div class='alert error'>❌ Mật khẩu mới và xác nhận không khớp!</div>";
    } elseif (strlen($new_pass) < 3) {
        $thongbao = "<div class='alert error'>❌ Mật khẩu mới phải có ít nhất 3 ký tự!</div>";
    } else {
        // Cập nhật mật khẩu mới
        $update_stmt = $conn->prepare("UPDATE tai_khoan SET password = ? WHERE username = ?");
        $update_stmt->bind_param("ss", $new_pass, $username);
        
        if ($update_stmt->execute()) {
            $thongbao = "<div class='alert success'>✅ Đổi mật khẩu thành công!</div>";
        } else {
            $thongbao = "<div class='alert error'>❌ Có lỗi xảy ra, vui lòng thử lại!</div>";
        }
        $update_stmt->close();
    }
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Đổi mật khẩu</title>
    <link rel="stylesheet" href="Matkhau.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        /* Thêm một chút CSS cho thông báo */
        .alert { padding: 10px; border-radius: 4px; margin-bottom: 15px; text-align: center; }
        .error { background: #fee2e2; color: #dc2626; border: 1px solid #fecaca; }
        .success { background: #dcfce7; color: #16a34a; border: 1px solid #bbf7d0; }
    </style>
</head>
<body>

<div class="container">
    <div class="header">
        <h1>Đổi mật khẩu</h1>
        <p>Cập nhật mật khẩu tài khoản của bạn (User: <strong><?php echo $_SESSION['username']; ?></strong>)</p>
    </div>

    <div class="card">
        <?php echo $thongbao; ?>

        <form method="POST" action="">
            <div class="form-group">
                <label>Mật khẩu hiện tại</label>
                <input type="password" name="old_pass" placeholder="Nhập mật khẩu cũ" required>
            </div>

            <div class="form-group">
                <label>Mật khẩu mới</label>
                <input type="password" name="new_pass" placeholder="Nhập mật khẩu mới" required>
            </div>

            <div class="form-group">
                <label>Xác nhận mật khẩu</label>
                <input type="password" name="confirm_pass" placeholder="Nhập lại mật khẩu" required>
            </div>

            <button type="submit" name="btn_update" class="btn-submit">
                <i class="fa fa-key"></i> Cập nhật mật khẩu
            </button>
        </form>
    </div>
</div>

<a href="Quanly.php" class="back-btn">
    ← Quay lại Tổng quan
</a>

</body>
</html>