<?php
session_start();

// 1. Kiểm tra quyền truy cập (Chỉ Admin mới được quản lý nhân viên)
if (!isset($_SESSION['username']) || !isset($_SESSION['vai_tro']) || $_SESSION['vai_tro'] != 1) {
    header("Location: Dangnhap.php");
    exit();
}

error_reporting(E_ALL);
ini_set('display_errors', 1);

// 2. Kết nối CSDL
$conn = new mysqli("localhost", "root", "", "cuahangtienloi");
if ($conn->connect_error) {
    die("Kết nối thất bại: " . $conn->connect_error);
}
$conn->set_charset("utf8");

// ================= XỬ LÝ THÊM =================
if(isset($_POST['them'])){
    $ten = $_POST['ten_nhan_vien'];
    $sdt = $_POST['so_dien_thoai'];
    $chucvu = $_POST['chuc_vu'];
    $calam = $_POST['ca_lam'];
    $trangthai = $_POST['trang_thai'];

    $conn->query("INSERT INTO nhan_vien(ten_nhan_vien, so_dien_thoai, chuc_vu, ca_lam, trang_thai) 
                  VALUES ('$ten', '$sdt', '$chucvu', '$calam', '$trangthai')");
    header("Location: Nhanvien.php");
    exit();
}

// ================= XỬ LÝ XÓA =================
if(isset($_GET['xoa'])){
    $id = $_GET['xoa'];
    $conn->query("DELETE FROM nhan_vien WHERE id_nhan_vien = $id");
    header("Location: Nhanvien.php");
    exit();
}

// ================= CHUẨN BỊ SỬA =================
$edit = null;
if(isset($_GET['sua'])){
    $id = $_GET['sua'];
    $kq = $conn->query("SELECT * FROM nhan_vien WHERE id_nhan_vien = $id");
    if($kq->num_rows > 0) $edit = $kq->fetch_assoc();
}

// ================= XỬ LÝ CẬP NHẬT =================
if(isset($_POST['capnhat'])){
    $id = $_POST['id_nhan_vien'];
    $ten = $_POST['ten_nhan_vien'];
    $sdt = $_POST['so_dien_thoai'];
    $chucvu = $_POST['chuc_vu'];
    $calam = $_POST['ca_lam'];
    $trangthai = $_POST['trang_thai'];

    $conn->query("UPDATE nhan_vien SET 
                  ten_nhan_vien='$ten', so_dien_thoai='$sdt', 
                  chuc_vu='$chucvu', ca_lam='$calam', trang_thai='$trangthai' 
                  WHERE id_nhan_vien=$id");
    header("Location: Nhanvien.php");
    exit();
}

// ================= TÌM KIẾM & LẤY DỮ LIỆU =================
$keyword = isset($_GET['keyword']) ? $_GET['keyword'] : "";
$sql = "SELECT * FROM nhan_vien WHERE ten_nhan_vien LIKE '%$keyword%' OR so_dien_thoai LIKE '%$keyword%' ORDER BY id_nhan_vien DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Quản lý Nhân viên</title>
    <link rel="stylesheet" href="Danhmuc.css"> 
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>

<div class="wrapper">
    <div class="header">
        <div>
            <h1>Quản lý Nhân viên</h1>
            <p>Điều hành và phân ca làm việc cho đội ngũ nhân sự</p>
        </div>
    </div>

    <div class="container-box">
        <div class="search-box card">
            <form method="GET">
                <input type="text" name="keyword" placeholder="🔍 Tìm tên hoặc số điện thoại nhân viên..." value="<?= htmlspecialchars($keyword) ?>">
                <button type="submit" class="btn-search">Tìm kiếm</button>
            </form>
        </div>

        <div class="form-them card">
            <h3><?= $edit ? '<i class="fa-solid fa-user-pen"></i> Cập nhật nhân viên' : '<i class="fa-solid fa-user-plus"></i> Thêm nhân viên mới' ?></h3>
            <form method="POST">
                <?php if($edit): ?>
                    <input type="hidden" name="id_nhan_vien" value="<?= $edit['id_nhan_vien'] ?>">
                <?php endif; ?>

                <div class="form-row">
                    <div class="form-group">
                        <label>Họ tên nhân viên</label>
                        <input type="text" name="ten_nhan_vien" value="<?= $edit['ten_nhan_vien'] ?? '' ?>" required>
                    </div>
                    <div class="form-group">
                        <label>Số điện thoại</label>
                        <input type="text" name="so_dien_thoai" value="<?= $edit['so_dien_thoai'] ?? '' ?>" required>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label>Chức vụ</label>
                        <select name="chuc_vu">
                            <option value="Nhân viên bán hàng" <?= (isset($edit) && $edit['chuc_vu'] == 'Nhân viên bán hàng') ? 'selected' : '' ?>>Nhân viên bán hàng</option>
                            <option value="Quản lý kho" <?= (isset($edit) && $edit['chuc_vu'] == 'Quản lý kho') ? 'selected' : '' ?>>Quản lý kho</option>
                            <option value="Bảo vệ" <?= (isset($edit) && $edit['chuc_vu'] == 'Bảo vệ') ? 'selected' : '' ?>>Bảo vệ</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Ca làm việc</label>
                        <select name="ca_lam">
                            <option value="Sáng (6h - 14h)" <?= (isset($edit) && $edit['ca_lam'] == 'Sáng (6h - 14h)') ? 'selected' : '' ?>>Sáng (6h - 14h)</option>
                            <option value="Chiều (14h - 22h)" <?= (isset($edit) && $edit['ca_lam'] == 'Chiều (14h - 22h)') ? 'selected' : '' ?>>Chiều (14h - 22h)</option>
                            <option value="Tối (22h - 6h)" <?= (isset($edit) && $edit['ca_lam'] == 'Tối (22h - 6h)') ? 'selected' : '' ?>>Tối (22h - 6h)</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Trạng thái</label>
                        <select name="trang_thai">
                            <option value="1" <?= (isset($edit) && $edit['trang_thai'] == 1) ? 'selected' : '' ?>>Đang làm việc</option>
                            <option value="0" <?= (isset($edit) && $edit['trang_thai'] == 0) ? 'selected' : '' ?>>Đã nghỉ việc</option>
                        </select>
                    </div>
                </div>

                <div class="form-actions">
                    <button type="submit" name="<?= $edit ? 'capnhat' : 'them' ?>" class="btn-save">
                        <?= $edit ? '💾 Lưu cập nhật' : '+ Thêm nhân viên' ?>
                    </button>
                    <?php if($edit): ?>
                        <a href="Nhanvien.php" class="btn-cancel">Hủy</a>
                    <?php endif; ?>
                </div>
            </form>
        </div>

        <div class="card">
            <table>
                <thead>
                    <tr>
                        <th>STT</th>
                        <th>Họ tên</th>
                        <th>SĐT</th>
                        <th>Chức vụ</th>
                        <th>Ca làm</th>
                        <th style="text-align: center;">Trạng thái</th>
                        <th style="text-align: center;">Hành động</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $stt = 1;
                    while($row = $result->fetch_assoc()): 
                    ?>
                    <tr>
                        <td><b><?= $stt++ ?></b></td>
                        <td><span style="font-weight: 600; color: #1e3a8a;"><?= $row['ten_nhan_vien'] ?></span></td>
                        <td><?= $row['so_dien_thoai'] ?></td>
                        <td><i class="fa-solid fa-briefcase" style="color: #64748b;"></i> <?= $row['chuc_vu'] ?></td>
                        <td><i class="fa-solid fa-clock" style="color: #64748b;"></i> <?= $row['ca_lam'] ?></td>
                        <td style="text-align: center;">
                            <?php if($row['trang_thai'] == 1): ?>
                                <span style="background: #dcfce7; color: #16a34a; padding: 4px 10px; border-radius: 20px; font-size: 12px; font-weight: bold;">Đang làm</span>
                            <?php else: ?>
                                <span style="background: #fee2e2; color: #dc2626; padding: 4px 10px; border-radius: 20px; font-size: 12px; font-weight: bold;">Đã nghỉ</span>
                            <?php endif; ?>
                        </td>
                        <td style="text-align: center;">
                            <a href="?sua=<?= $row['id_nhan_vien'] ?>" class="action-btn edit"><i class="fa-solid fa-pen"></i></a>
                            <a href="?xoa=<?= $row['id_nhan_vien'] ?>" class="action-btn delete" onclick="return confirm('Xác nhận cho nghỉ việc/xóa nhân viên này?')"><i class="fa-solid fa-trash"></i></a>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>

    <a href="Quanly.php" class="back-btn">
        <i class="fa-solid fa-arrow-left"></i> Quay lại Tổng quan
    </a>
</div>

</body>
</html>