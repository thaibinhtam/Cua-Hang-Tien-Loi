<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

// 1. Kiểm tra quyền (Chỉ Admin/Nhân viên mới được vào đây)
if (!isset($_SESSION['username']) || !isset($_SESSION['vai_tro']) || $_SESSION['vai_tro'] != 1) {
    header("Location: Dangnhap.php");
    exit();
}

// 2. Kết nối CSDL
$conn = new mysqli("localhost", "root", "", "cuahangtienloi");
$conn->set_charset("utf8");

// Khởi tạo giỏ hàng POS
if (!isset($_SESSION['pos_cart'])) {
    $_SESSION['pos_cart'] = [];
}

// ================= XỬ LÝ THÊM/BỚT MÓN TRÊN POS =================
if (isset($_GET['action']) && isset($_GET['id'])) {
    $id = $_GET['id'];
    $action = $_GET['action'];

    if ($action == 'add') {
        // Lấy thông tin sản phẩm CỤ THỂ từ DB dựa vào $id để ném vào giỏ
        $sql = "SELECT * FROM sanpham WHERE id = '$id'";
        $result = $conn->query($sql);
        if ($result && $result->num_rows > 0) {
            $sp = $result->fetch_assoc();
            if (isset($_SESSION['pos_cart'][$id])) {
                $_SESSION['pos_cart'][$id]['sl'] += 1;
            } else {
                $_SESSION['pos_cart'][$id] = [
                    'ten' => $sp['ten_sp'],
                    'gia' => $sp['gia'],
                    'sl' => 1
                ];
            }
        }
    } elseif ($action == 'giam') {
        if (isset($_SESSION['pos_cart'][$id])) {
            $_SESSION['pos_cart'][$id]['sl'] -= 1;
            if ($_SESSION['pos_cart'][$id]['sl'] <= 0) unset($_SESSION['pos_cart'][$id]);
        }
    } elseif ($action == 'xoa') {
        unset($_SESSION['pos_cart'][$id]);
    } elseif ($action == 'huy') {
        $_SESSION['pos_cart'] = []; // Xóa trắng giỏ hàng để đón khách mới
    }
    
    header("Location: POS.php");
    exit();
}

// Tính tổng tiền
$tong_tien = 0;
if (!empty($_SESSION['pos_cart'])) {
    foreach ($_SESSION['pos_cart'] as $item) {
        $tong_tien += ($item['gia'] * $item['sl']);
    }
} else {
    $tong_tien = 0;
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>POS - Bán Hàng Tại Quầy</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
    * { box-sizing: border-box; margin: 0; padding: 0; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
    body { background: #f1f5f9; display: flex; height: 100vh; overflow: hidden; }
    
    /* CỘT TRÁI: DANH SÁCH SẢN PHẨM */
    .products-section { flex: 7; padding: 15px; overflow-y: auto; background: #f1f5f9; }
    .header-pos { display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px; }
    
    /* ÉP LƯỚI SIÊU NHỎ: Kích thước mỗi ô chỉ còn 100px */
    .product-grid { 
        display: grid; 
        grid-template-columns: repeat(auto-fill, minmax(100px, 1fr)); 
        gap: 10px; 
    }
    
    /* THIẾT KẾ LẠI Ô SẢN PHẨM DẠNG NÚT BẤM POS (KHÔNG DÙNG ẢNH) */
    .product-card { 
        background: #fff; 
        padding: 10px 5px; 
        border-radius: 6px; 
        text-align: center; 
        cursor: pointer; 
        transition: 0.2s;
        border: 2px solid #e2e8f0;
        display: flex; 
        flex-direction: column; 
        justify-content: center;
        align-items: center;
        height: 90px; /* Ép chiều cao cố định để thành hình vuông nhỏ */
        box-shadow: 0 1px 3px rgba(0,0,0,0.1);
    }
    .product-card:hover { 
        border-color: #10b981; /* Đổi viền xanh lá khi trỏ chuột */
        background: #ecfdf5;
        transform: translateY(-2px); 
    }
    .product-card h3 { 
        font-size: 12px; /* Chữ nhỏ lại */
        color: #334155; 
        margin-bottom: 5px; 
        display: -webkit-box; 
        -webkit-line-clamp: 2; /* Tối đa 2 dòng, dài quá tự có dấu ... */
        -webkit-box-orient: vertical; 
        overflow: hidden;
        font-weight: 600;
        line-height: 1.3;
    }
    .product-card .price { 
        color: #ef4444; 
        font-weight: bold; 
        font-size: 13px; 
    }

    /* CỘT PHẢI: HÓA ĐƠN (Thu gọn lại cho tinh tế) */
    .bill-section { flex: 3; background: #fff; border-left: 1px solid #cbd5e1; display: flex; flex-direction: column; box-shadow: -5px 0 15px rgba(0,0,0,0.05); }
    .bill-header { padding: 15px; background: #1e293b; color: white; text-align: center; font-size: 16px; font-weight: bold; }
    .bill-items { flex: 1; overflow-y: auto; padding: 10px; }
    .bill-item { display: flex; justify-content: space-between; align-items: center; padding-bottom: 10px; margin-bottom: 10px; border-bottom: 1px dashed #cbd5e1; }
    .item-info { flex: 1; }
    .item-name { font-weight: bold; color: #1e293b; margin-bottom: 5px; font-size: 13px; }
    .item-qty-control { display: flex; align-items: center; gap: 8px; }
    .qty-btn { background: #e2e8f0; color: #0f172a; width: 22px; height: 22px; text-align: center; line-height: 22px; border-radius: 4px; text-decoration: none; font-weight: bold; font-size: 14px;}
    .qty-btn:hover { background: #cbd5e1; }
    .item-price { font-weight: bold; color: #ef4444; font-size: 13px;}
    
    .bill-footer { padding: 15px; background: #f8fafc; border-top: 1px solid #cbd5e1; }
    .total-row { display: flex; justify-content: space-between; font-size: 18px; font-weight: bold; color: #0f172a; margin-bottom: 15px; }
    .btn-checkout { display: block; width: 100%; padding: 12px; background: #10b981; color: white; text-align: center; text-decoration: none; font-size: 16px; font-weight: bold; border-radius: 6px; border: none; cursor: pointer; }
    .btn-checkout:hover { background: #059669; }
    .btn-cancel { display: block; width: 100%; padding: 10px; background: #f1f5f9; color: #ef4444; text-align: center; text-decoration: none; font-weight: bold; border-radius: 6px; margin-top: 10px; }
</style>
</head>
<body>

    <div class="products-section">
        <div class="header-pos">
            <h2><i class="fa-solid fa-store"></i> Menu Sản Phẩm</h2>
            <a href="Quanly.php" style="color: #64748b; text-decoration: none;"><i class="fa-solid fa-arrow-left"></i> Về trang Quản lý</a>
        </div>
        
        <div class="product-grid">
            <?php 
            $sp_query = $conn->query("SELECT * FROM sanpham ORDER BY id DESC");
            while($row = $sp_query->fetch_assoc()): 
            ?>
            <div class="product-card" onclick="window.location.href='POS.php?action=add&id=<?= $row['id'] ?>'">
                <h3><?= $row['ten_sp'] ?></h3>
                <div class="price"><?= number_format($row['gia'], 0, ',', '.') ?>đ</div>
            </div>
            <?php endwhile; ?>
        </div>
    </div>

    <div class="bill-section">
        <div class="bill-header">
            <i class="fa-solid fa-receipt"></i> Đơn Hàng Hiện Tại
        </div>
        
        <div class="bill-items">
            <?php if(empty($_SESSION['pos_cart'])): ?>
                <div style="text-align: center; color: #94a3b8; margin-top: 50px;">
                    <i class="fa-solid fa-cart-arrow-down" style="font-size: 40px; margin-bottom: 10px;"></i>
                    <p>Chưa có sản phẩm nào</p>
                </div>
            <?php else: ?>
                <?php foreach($_SESSION['pos_cart'] as $id => $item): ?>
                <div class="bill-item">
                    <div class="item-info">
                        <div class="item-name"><?= $item['ten'] ?></div>
                        <div class="item-qty-control">
                            <a href="POS.php?action=giam&id=<?= $id ?>" class="qty-btn">-</a>
                            <span><?= $item['sl'] ?></span>
                            <a href="POS.php?action=add&id=<?= $id ?>" class="qty-btn">+</a>
                        </div>
                    </div>
                    <div style="text-align: right;">
                        <div class="item-price"><?= number_format($item['gia'] * $item['sl'], 0, ',', '.') ?>đ</div>
                        <a href="POS.php?action=xoa&id=<?= $id ?>" style="color: #ef4444; font-size: 12px; text-decoration: none;"><i class="fa-solid fa-trash"></i> Xóa</a>
                    </div>
                </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>

        <div class="bill-footer">
            <div class="total-row">
                <span>Tổng tiền:</span>
                <span style="color: #ef4444;"><?= number_format($tong_tien, 0, ',', '.') ?>đ</span>
            </div>
            
            <?php if(!empty($_SESSION['pos_cart'])): ?>
                <form action="XulyPOS.php" method="POST">
                    <input type="hidden" name="tong_tien" value="<?= $tong_tien ?>">
                    <button type="submit" name="btn_thanhtoan" class="btn-checkout">
                        <i class="fa-solid fa-money-bill-wave"></i> THANH TOÁN
                    </button>
                </form>
                <a href="POS.php?action=huy" class="btn-cancel" onclick="return confirm('Bạn muốn hủy đơn này?')">Hủy đơn</a>
            <?php else: ?>
                <button class="btn-checkout" style="background: #94a3b8; cursor: not-allowed;" disabled>THANH TOÁN</button>
            <?php endif; ?>
        </div>
    </div>

</body>
</html>