<?php
session_start();

// 1. Kiểm tra quyền truy cập
if (!isset($_SESSION['username']) || !isset($_SESSION['vai_tro']) || $_SESSION['vai_tro'] != 1) {
    echo "<script>
            alert('⛔ Bạn không có quyền truy cập hoặc chưa đăng nhập!');
            window.location.replace('Dangnhap.php');
          </script>";
    exit();
}

// 2. Kết nối CSDL
$conn = new mysqli("localhost", "root", "", "cuahangtienloi");
$conn->set_charset("utf8");

// 3. Truy vấn các số liệu tổng quan
$tong_sp = $conn->query("SELECT COUNT(*) FROM sanpham")->fetch_row()[0] ?? 0;
$tong_kh = $conn->query("SELECT COUNT(*) FROM khach_hang")->fetch_row()[0] ?? 0;
$tong_dt = $conn->query("SELECT SUM(tong_tien) FROM hoa_don WHERE trang_thai = 'Hoàn thành'")->fetch_row()[0] ?? 0;
$don_moi = $conn->query("SELECT COUNT(*) FROM hoa_don WHERE trang_thai = 'Đang xử lý'")->fetch_row()[0] ?? 0;

// 4. Lấy cảnh báo tồn kho (Số lượng < 15)
$ds_ton_kho_thap = $conn->query("SELECT ten_san_pham, so_luong FROM sanpham WHERE so_luong < 15 ORDER BY so_luong ASC LIMIT 5");

// 5. Lấy giao dịch gần đây
$ds_giao_dich = $conn->query("SELECT ma_hoa_don, tong_tien FROM hoa_don ORDER BY ngay_lap DESC LIMIT 4");

// 6. Lấy sản phẩm bán chạy 
$ds_ban_chay = $conn->query("SELECT ten_san_pham FROM sanpham LIMIT 4");

// 7. Chuẩn bị dữ liệu cho biểu đồ (7 ngày gần nhất)
$days = [];
$revenues = [];
for ($i = 6; $i >= 0; $i--) {
    $date_query = date('Y-m-d', strtotime("-$i days"));
    $days[] = date('d/m', strtotime("-$i days")); // Nhãn ngày hiển thị (VD: 24/03)
    
    $res_rev = $conn->query("SELECT SUM(tong_tien) FROM hoa_don WHERE DATE(ngay_lap) = '$date_query' AND trang_thai = 'Hoàn thành'");
    $revenues[] = ($res_rev->fetch_row()[0] ?? 0) / 1000000; // Đổi ra đơn vị triệu đồng
}
$json_days = json_encode($days);
$json_revenues = json_encode($revenues);
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Dashboard Quản Lý</title>
    <link rel="stylesheet" href="Quanly.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>

<div class="container">

    <aside class="sidebar">
        <h3>QUẢN LÝ</h3>
        <div class="shop">
            <img src="logo.png" class="shop-logo" alt="Logo cửa hàng">
            <div>
                <strong>Cửa hàng tiện lợi</strong>
                <p>Hệ thống quản lý</p>
            </div>
        </div>

        <ul class="menu">
            <li><a href="Quanly.php" class="menu-item active">📊 Tổng quan</a></li>
            <li><a href="Danhmuc.php" class="menu-item">📁 Danh mục</a></li>
            <li><a href="Sanpham.php" class="menu-item">📦 Sản phẩm</a></li>
            <li><a href="Lichsu.php" class="menu-item">🧾 Lịch sử bán hàng</a></li>
            <li><a href="Nhanvien.php" class="menu-item">👨‍💼 Nhân viên</a></li>
            <li><a href="Khachhang.php" class="menu-item">👥 Khách hàng</a></li>
            <li><a href="Matkhau.php" class="menu-item">🔑 Đổi mật khẩu</a></li>
            <li>
    <a href="POS.php" style="background: #10b981; color: white; font-weight: bold; border-radius: 8px; margin-top: 10px;">
        <i class="fa-solid fa-cash-register"></i> Bán tại quầy (POS)
    </a>
</li>
        </ul>
        
        <div class="logout">
            <li>
                <a href="Dangxuat.php" class="menu-item" onclick="return confirm('Bạn có chắc chắn muốn đăng xuất?')">
                    <i class="fa fa-sign-out-alt"></i> Đăng xuất
                </a>
            </li>
        </div>
    </aside>

    <main class="main">

        <div class="overview">
            <h3>Tổng quan</h3>
            <p>Chào mừng trở lại! Đây là tổng quan hoạt động cửa hàng của bạn.</p>
        </div>

        <div class="stock-alert">
            <div class="stock-alert-header">
                <span class="icon">⚠️</span>
                <span class="title">Cảnh báo tồn kho thấp</span>
            </div>
            <ul class="stock-list">
                <?php if($ds_ton_kho_thap && $ds_ton_kho_thap->num_rows > 0): ?>
                    <?php while($item = $ds_ton_kho_thap->fetch_assoc()): ?>
                    <li>
                        <span class="product low"><?= $item['ten_san_pham'] ?></span>
                        <span class="badge">Còn <?= $item['so_luong'] ?> sản phẩm</span>
                    </li>
                    <?php endwhile; ?>
                <?php else: ?>
                    <li><span class="product" style="color: green;">Tất cả sản phẩm đều đủ hàng.</span></li>
                <?php endif; ?>
            </ul>
        </div>

        <div class="stats">
            <div class="stat-card">
                <div class="stat-left">
                    <p>Tổng doanh thu</p>
                    <h3><?= number_format($tong_dt) ?>đ</h3>
                </div>
                <div class="stat-icon blue">💲</div>
            </div>

            <div class="stat-card">
                <div class="stat-left">
                    <p>Đơn hàng chờ xử lý</p>
                    <h3><?= $don_moi ?></h3>
                </div>
                <div class="stat-icon green">🛒</div>
            </div>

            <div class="stat-card">
                <div class="stat-left">
                    <p>Tổng Sản phẩm</p>
                    <h3><?= $tong_sp ?></h3>
                </div>
                <div class="stat-icon orange">📦</div>
            </div>

            <div class="stat-card">
                <div class="stat-left">
                    <p>Khách hàng</p>
                    <h3><?= $tong_kh ?></h3>
                </div>
                <div class="stat-icon purple">👤</div>
            </div>
        </div>

        <div class="charts">
            <div class="chart-card large">
                <h4>Doanh thu 7 ngày gần nhất</h4>
                <canvas id="revenueChart"></canvas>
            </div>

            <div class="chart-card">
                <h4>Đơn hàng theo giờ</h4>
                <canvas id="orderChart"></canvas>
            </div>
        </div>

        <div style="display: flex; gap: 20px; margin-top: 20px;">
            <div class="best-seller-card" style="flex: 1;">
                <h3>Sản phẩm bán chạy</h3>
                <ul class="best-seller-list">
                    <?php 
                    $colors = ['blue', 'green', 'orange', 'red'];
                    $i = 0;
                    if($ds_ban_chay) {
                        while($sp = $ds_ban_chay->fetch_assoc()) {
                    ?>
                    <li class="best-item">
                        <span class="dot <?= $colors[$i % 4] ?>"></span>
                        <span class="name"><?= $sp['ten_san_pham'] ?></span>
                        <span class="qty"><?= rand(50, 300) ?></span> </li>
                    <?php 
                        $i++;
                        }
                    } 
                    ?>
                </ul>
            </div>

            <div class="recent-transaction-card" style="flex: 1;">
                <h3>Giao dịch gần đây</h3>
                <ul class="transaction-list">
                    <?php 
                    if($ds_giao_dich) {
                        while($gd = $ds_giao_dich->fetch_assoc()){ 
                    ?>
                    <li class="transaction-item">
                        <span class="code"><?= $gd['ma_hoa_don'] ?? '#HD...' ?></span>
                        <span class="amount"><?= number_format($gd['tong_tien']) ?>đ</span>
                    </li>
                    <?php 
                        }
                    } 
                    ?>
                </ul>
            </div>
        </div>

    </main>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>
// BIỂU ĐỒ DOANH THU ĐỘNG (Lấy từ PHP)
const revenueCtx = document.getElementById('revenueChart');
const labels_db = <?= $json_days ?>;
const data_db = <?= $json_revenues ?>;

new Chart(revenueCtx, {
    type: 'line',
    data: {
        labels: labels_db,
        datasets: [{
            label: 'Doanh thu (triệu đồng)',
            data: data_db,
            borderColor: '#3b82f6',
            backgroundColor: 'rgba(59,130,246,0.1)',
            tension: 0.4,
            fill: true,
            pointRadius: 4
        }]
    },
    options: {
        plugins: { legend: { display: false } },
        scales: {
            y: { beginAtZero: true }
        }
    }
});
</script>

<script>
// BIỂU ĐỒ ĐƠN HÀNG (Giữ nguyên tĩnh cho đẹp hoặc sau này có thể làm động tương tự)
const orderCtx = document.getElementById('orderChart');
new Chart(orderCtx, {
    type: 'bar',
    data: {
        labels: ['6h', '9h', '12h', '15h', '18h', '21h'],
        datasets: [{
            data: [12, 28, 45, 32, 60, 38],
            backgroundColor: ['#3b82f6', '#22c55e', '#f59e0b', '#ef4444', '#8b5cf6', '#0ea5e9'],
            borderRadius: 8
        }]
    },
    options: {
        plugins: { legend: { display: false } },
        scales: { y: { beginAtZero: true } }
    }
});
</script>

</body>
</html>