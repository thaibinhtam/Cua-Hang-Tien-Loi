<?php
session_start();
if (!isset($_SESSION['username']) || !isset($_SESSION['vai_tro']) || $_SESSION['vai_tro'] != 1) {
    echo "<script>
            alert('⛔ Bạn không có quyền truy cập hoặc chưa đăng nhập!');
            window.location.replace('Dangnhap.php');
          </script>";
    exit();
}
?>
<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$conn = new mysqli("localhost", "root", "", "cuahangtienloi");
if ($conn->connect_error) {
    die("Kết nối thất bại: " . $conn->connect_error);
}
$conn->set_charset("utf8");

// ================= THÊM =================
if(isset($_POST['them'])){
    $ten = $_POST['ten_sp'];
    $gia = $_POST['gia'];
    $danh_muc = $_POST['danh_muc'];

    // Đã thay đổi tên cột cho khớp DB (tạm thời bỏ so_luong vì DB không có)
    $conn->query("INSERT INTO sanpham(ten_sp, gia, danh_muc)
                  VALUES ('$ten','$gia','$danh_muc')");

    header("Location: Sanpham_admin.php");
    exit();
}

// ================= XÓA =================
if(isset($_GET['xoa'])){
    $id = $_GET['xoa'];
    // Đã sửa id_san_pham thành id
    $conn->query("DELETE FROM sanpham WHERE id=$id");

    header("Location: Sanpham_admin.php");
    exit();
}

// ================= SỬA =================
$edit = null;
if(isset($_GET['sua'])){
    $id = $_GET['sua'];
    // Đã sửa id_san_pham thành id
    $kq = $conn->query("SELECT * FROM sanpham WHERE id=$id");
    $edit = $kq->fetch_assoc();
}

// ================= UPDATE =================
if(isset($_POST['capnhat'])){
    $id = $_POST['id'];
    $ten = $_POST['ten_sp'];
    $gia = $_POST['gia'];
    $danh_muc = $_POST['danh_muc'];

    // Đã sửa tên cột cho khớp DB
    $conn->query("UPDATE sanpham 
                  SET ten_sp='$ten',
                      gia='$gia',
                      danh_muc='$danh_muc'
                  WHERE id=$id");

    header("Location: Sanpham_admin.php");
    exit();
}

// ================= SEARCH =================
$keyword = "";
if(isset($_GET['keyword'])){
    $keyword = $_GET['keyword'];
}

// ================= LẤY DỮ LIỆU =================
// Đã ghép nối chuẩn danh_muc của sanpham với id_danh_muc của danh_muc
$sql = "SELECT sanpham.*, danh_muc.ten_danh_muc
        FROM sanpham
        LEFT JOIN danh_muc 
        ON sanpham.danh_muc = danh_muc.id_danh_muc
        WHERE sanpham.ten_sp LIKE '%$keyword%'
        ORDER BY sanpham.id DESC";

$result = $conn->query($sql);

// LẤY DANH MỤC CHO DROPDOWN
$danhmuc_query = $conn->query("SELECT * FROM danh_muc");
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Quản lý sản phẩm</title>
    <link rel="stylesheet" href="Danhmuc.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>

<div class="wrapper">

    <div class="header">
        <div>
            <h1>Quản lý sản phẩm</h1>
            <p>Quản lý sản phẩm cửa hàng</p>
        </div>
    </div>

    <div class="container-box">

        <div class="search-box card">
            <form method="GET">
                <input type="text" name="keyword" placeholder="🔍 Tìm sản phẩm..." value="<?= htmlspecialchars($keyword); ?>">
            </form>
        </div>

<?php if($edit){ ?>
<div class="form-them card">
    <h3>✏️ Sửa sản phẩm</h3>
    <form method="POST">
        <input type="hidden" name="id" value="<?= $edit['id']; ?>">

        <div class="form-row">
            <div class="form-group">
                <label>Tên sản phẩm</label>
                <input type="text" name="ten_sp"
                       value="<?= $edit['ten_sp']; ?>" required>
            </div>

            <div class="form-group">
                <label>Giá</label>
                <input type="number" name="gia"
                       value="<?= $edit['gia']; ?>" required>
            </div>

            <div class="form-group">
                <label>Danh mục</label>
                <select name="danh_muc" required>
                    <?php while($dm = $danhmuc_query->fetch_assoc()) { ?>
                        <option value="<?= $dm['id_danh_muc']; ?>"
                            <?= ($dm['id_danh_muc'] == $edit['danh_muc']) ? "selected" : ""; ?>>
                            <?= $dm['ten_danh_muc']; ?>
                        </option>
                    <?php } ?>
                </select>
            </div>
        </div>

        <button type="submit" name="capnhat">💾 Cập nhật</button>
        <a href="Sanpham_admin.php">Hủy</a>
    </form>
</div>

<?php } else { ?>
<div class="form-them card">
    <h3>➕ Thêm sản phẩm</h3>
    <form method="POST">
        <div class="form-row">
            <div class="form-group">
                <label>Tên sản phẩm</label>
                <input type="text" name="ten_sp" required>
            </div>

            <div class="form-group">
                <label>Giá</label>
                <input type="number" name="gia" required>
            </div>

            <div class="form-group">
                <label>Danh mục</label>
                <select name="danh_muc" required>
                    <?php
                    // Chạy lại query để lấy danh sách do query trên đã bị fetch_assoc hết
                    $danhmuc_add = $conn->query("SELECT * FROM danh_muc");
                    while($dm = $danhmuc_add->fetch_assoc()) {
                    ?>
                        <option value="<?= $dm['id_danh_muc']; ?>">
                            <?= $dm['ten_danh_muc']; ?>
                        </option>
                    <?php } ?>
                </select>
            </div>
        </div>

        <button type="submit" name="them">+ Thêm</button>
    </form>
</div>
<?php } ?>

        <div class="card">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Tên</th>
                        <th>Giá</th>
                        <th>Danh mục</th>
                        <th>Hành động</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while($row = $result->fetch_assoc()) { ?>
                    <tr>
                        <td><?= $row['id']; ?></td>
                        <td><?= $row['ten_sp']; ?></td>
                        <td><span style="color: #e11d48; font-weight: bold;"><?= number_format($row['gia'], 0, ',', '.'); ?>đ</span></td>
                        <td><?= $row['ten_danh_muc']; ?></td>
                        <td>
                            <a href="?sua=<?= $row['id']; ?>" class="edit">✏️</a>
                            <a href="?xoa=<?= $row['id']; ?>"
                               class="delete"
                               onclick="return confirm('Bạn có chắc chắn muốn xóa sản phẩm này không?')">🗑️</a>
                        </td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>

    </div>
</div>
<a href="Quanly.php" class="back-btn">
    ← Quay lại Tổng quan
</a>
</body>
</html>