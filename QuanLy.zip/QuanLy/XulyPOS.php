<?php
session_start();
// THIẾT LẬP MÚI GIỜ VIỆT NAM
date_default_timezone_set('Asia/Ho_Chi_Minh');

// 1. Kiểm tra quyền (Chỉ Admin/Nhân viên mới được vô)
if (!isset($_SESSION['username']) || !isset($_SESSION['vai_tro']) || $_SESSION['vai_tro'] != 1) {
    header("Location: Dangnhap.php");
    exit();
}

// 2. Kiểm tra xem có bấm nút thanh toán và giỏ hàng POS có đồ không
if (isset($_POST['btn_thanhtoan']) && !empty($_SESSION['pos_cart'])) {
    
    // Kết nối CSDL
    $conn = new mysqli("localhost", "root", "", "cuahangtienloi");
    $conn->set_charset("utf8");

    // Lấy dữ liệu
    $tong_tien = $_POST['tong_tien'];
    $ma_hd = "POS" . time(); // Tạo mã hóa đơn tự động (VD: POS1715000000)
    $ngay_lap = date("Y-m-d H:i:s");

    // BƯỚC 1: Lưu vào bảng don_hang
    // Vì khách vãng lai mua tại quầy nên id_khach_hang mình để NULL, trạng thái là "Hoàn thành" luôn
    $sql_hd = "INSERT INTO don_hang (ma_hd, id_khach_hang, ngay, tong_tien, thanh_toan, trang_thai) 
               VALUES ('$ma_hd', NULL, '$ngay_lap', '$tong_tien', 'Tiền mặt', 'Hoàn thành')";
    
    if ($conn->query($sql_hd) === TRUE) {
        // Lấy được ID của hóa đơn vừa tạo xong
        $id_don_hang = $conn->insert_id; 

        // BƯỚC 2: Lưu từng món vào chi_tiet_don_hang và Trừ tồn kho
        foreach ($_SESSION['pos_cart'] as $id_sp => $item) {
            $sl = $item['sl'];
            $gia = $item['gia'];

            // Thêm vào bảng chi tiết
            $conn->query("INSERT INTO chi_tiet_don_hang (id_don_hang, id_san_pham, so_luong, gia) 
                          VALUES ('$id_don_hang', '$id_sp', '$sl', '$gia')");

            // Trừ số lượng tồn kho của sản phẩm đó
            $conn->query("UPDATE sanpham SET so_luong = so_luong - $sl WHERE id = $id_sp");
        }

        // BƯỚC 3: Xóa giỏ hàng POS để đón khách tiếp theo
        unset($_SESSION['pos_cart']);

        // BƯỚC 4: Chuyển sang trang In Hóa Đơn
        header("Location: InBill.php?ma_hd=" . $ma_hd);
        exit();

    } else {
        die("Lỗi lưu hóa đơn: " . $conn->error);
    }

} else {
    // Nếu giỏ hàng trống mà cố tình vào file này thì đá về lại POS
    header("Location: POS.php");
    exit();
}
?>